module.exports = {
    'facebookAuth' : {
        'clientID'      : '762868437069360', // your App ID
        'clientSecret'  : '55f4bc8240f580d07d36517faf04913a', // your App Secret
        'callbackURL'   : 'http://localhost:3000/auth/facebook/callback'
    },

    'googleAuth' : {
        'clientID'      : '11195848805-ibkdjcnu6jbslr3b8tsiiop3dfcn8ed4.apps.googleusercontent.com',
        'clientSecret'  : '2_pFQkm6bf5OlFWMfkGHqaPd',
        'callbackURL'   : 'http://localhost:3000/auth/google/callback'
    }
    /*'facebookAuth' : {
        'clientID'      : '710127715736307', // your App ID
        'clientSecret'  : '285839046b558850b4d7987d01fd7eda', // your App Secret
        'callbackURL'   : 'https://azquestion.com/auth/facebook/callback'
    },

    'googleAuth' : {
        'clientID'      : '706056968878-4urgtb4rn4o8296rlojh9rec8a9sm72l.apps.googleusercontent.com',
        'clientSecret'  : 'M3Lf7ickOmWDDQe8fXSH50aV',
        'callbackURL'   : 'https://azquestion.com/auth/google/callback'
    }*/

};
