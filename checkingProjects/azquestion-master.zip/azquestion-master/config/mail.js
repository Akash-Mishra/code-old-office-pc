module.exports = {
    'gmail': {
        'service': 'Gmail',
        'user': 'demo.azquestion.com@gmail.com',
        'pass': 'fit@dhcn123!@#'
    },
};
