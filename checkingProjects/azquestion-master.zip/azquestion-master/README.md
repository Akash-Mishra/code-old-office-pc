See demo here : <https://azquestion-sangnguyenplus.c9users.io>

Admin: minhsang2603@gmail.com - 159357

User: sangit7b@gmail.com - 123456789

**Required**: Please install them before install azquestion
- NodeJS: > 10.0.x.
- Bower (run `npm install -g bower` after install NodeJS).
- MongoDB.

**Installation**:

Run command below to get NodeJS libraries.

```
npm install
```

**If you get error and npm don't install some libraries with bower (you can check if not exists bower_components folder). Please run below command:**

```
bower install
```

**Restore database (need to install MongoDB first)**: open cmd, cd to db folder and run below command
```
mongorestore
```

Run `node server` and see it in **http://localhost:3000**
